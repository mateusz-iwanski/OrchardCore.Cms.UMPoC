﻿using System.Threading.Tasks;
using OrchardCore.ContentManagement.Metadata;
using OrchardCore.ContentManagement.Metadata.Settings;
using OrchardCore.Data.Migration;
using UMPoC.Mvc.FacultyAnnouncementModule.Models;

namespace UMPoC.Mvc.FacultyAnnouncementModule.Migrations
{
    public class FacultyAnnouncementMigrations : DataMigration
    {
        private readonly IContentDefinitionManager _contentDefinitionManager;

        public FacultyAnnouncementMigrations(IContentDefinitionManager contentDefinitionManager)
        {
            _contentDefinitionManager = contentDefinitionManager;
        }

        public async Task<int> CreateAsync()
        {
            // Pierwsze utworzenie Parta
            await _contentDefinitionManager.AlterPartDefinitionAsync(nameof(FacultyAnnouncementPart), part => part
                .Attachable()
                .WithDescription("Faculty announcement audit part.")
            );

            return 1;
        }

        public async Task<int> UpdateFrom1Async()
        {
            // Ponowne nadanie attachable, gdyby ktoś miał starszą migrację
            await _contentDefinitionManager.AlterPartDefinitionAsync(nameof(FacultyAnnouncementPart), part => part
                .Attachable()
                .WithDescription("Faculty announcement audit part.")
            );

            return 2;
        }

    }
}
